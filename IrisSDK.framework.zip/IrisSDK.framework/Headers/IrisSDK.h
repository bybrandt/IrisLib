//
//  IrisSDK.h
//  IrisSDK
//
//  Created by Thiago Rodrigo Da Costa Brandt on 11/09/19.
//  Copyright © 2019 Iris Data Driven Marketing. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for IrisSDK.
FOUNDATION_EXPORT double IrisSDKVersionNumber;

//! Project version string for IrisSDK.
FOUNDATION_EXPORT const unsigned char IrisSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <IrisSDK/PublicHeader.h>


