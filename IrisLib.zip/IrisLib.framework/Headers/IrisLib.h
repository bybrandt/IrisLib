//
//  IrisLib.h
//  IrisLib
//
//  Created by Thiago Rodrigo Da Costa Brandt on 04/09/19.
//  Copyright © 2019 Thiago Rodrigo Da Costa Brandt. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for IrisLib.
FOUNDATION_EXPORT double IrisLibVersionNumber;

//! Project version string for IrisLib.
FOUNDATION_EXPORT const unsigned char IrisLibVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <IrisLib/PublicHeader.h>


